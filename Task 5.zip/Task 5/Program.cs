﻿using Exam02.Classes;

namespace Task_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Subject subject = new Subject(10, ".Net Programming");
            subject.CreateExam();
            Console.Write("Do You want to Start The Exam (Y|N):");
            char ch;
            char.TryParse(Console.ReadLine(), out ch);
            if (ch == 'Y' || ch == 'y')
            {
                subject.Exam.ShowExam();
            }

        }
    }
}
