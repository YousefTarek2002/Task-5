﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam02.Classes
{
    public class Subject
    {
        #region Properties
        public int ID { get; set; }
        public string Name { get; set; }
        public Exam Exam { get; set; }
        #endregion

        #region Constructors
        public Subject(int _ID, string _Name)
        {
            ID = _ID;
            Name = _Name;
        }
        #endregion

        #region Methods
        public void CreateExam()
        {
            int ExamType;
            do
            {
                Console.Write($"Please Enter The Exam type (1 for Practical, 2 for Final): ");
                int.TryParse(Console.ReadLine(), out ExamType);
            }while(ExamType != 1 &&  ExamType != 2);
            if(ExamType == 1)
            {
                Exam = new PracticalExam();
            }
            else
            {
                Exam = new FinalExam();
            }
        }


        #endregion
    }
}
