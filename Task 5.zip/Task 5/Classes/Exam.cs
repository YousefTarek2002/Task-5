﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam02.Classes
{
    public abstract class Exam
    {
        #region Properties
        public int TimeOfExam { get; set; }
        public int NumberOfQuestions { get; set; }
        public int Grade { get; set; }
        public int TotalMarks { get; set; }
        #endregion

        #region Constructors
        public Exam()
        {
            int _Time;
            do
            {
                Console.Write("Please Enter The Time of Exam: ");
                int.TryParse(Console.ReadLine(), out _Time);
            } while (_Time <= 0);
            TimeOfExam = _Time;
            int _NumberOfQuestions;
            do
            {
                Console.Write("Please Enter The Number of Questions You Want to create: ");
                int.TryParse(Console.ReadLine(), out _NumberOfQuestions);
            } while (_NumberOfQuestions <= 0);
            NumberOfQuestions = _NumberOfQuestions;
            Grade = 0;
            TotalMarks = 0;
        }

        public Exam(int timeOfExam, int numberOfQuestions)
        {
            TimeOfExam = timeOfExam;
            NumberOfQuestions = numberOfQuestions;
            Grade = 0;
            TotalMarks = 0;
        }
        #endregion

        #region Methods
        public abstract void ShowExam();

        public override string ToString()
        {
            return $"Time of tne Exam: {TimeOfExam}, Number of Questions: {NumberOfQuestions}";
        }

        #endregion
    }
}
