﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam02.Classes
{
    public class PracticalExam : Exam
    {
        #region Properties
        public MCQQuestion[] MCQQuestions { get; set; }
        public int[] MCQAnswers { get; set; }
        #endregion

        #region Constructors
        public PracticalExam():base()
        {
            MCQQuestions = new MCQQuestion[NumberOfQuestions];
            MCQAnswers = new int[NumberOfQuestions];
            for(int i=0;i<NumberOfQuestions; i++)
            {
                MCQQuestions[i] = new MCQQuestion();
                TotalMarks += MCQQuestions[i].Mark;
            }
        }

        public PracticalExam(int _TimeOfExam, int _NumberofQuestions, MCQQuestion[] _MCQQuestion, int _TotalMarks)
            : base(_TimeOfExam, _NumberofQuestions)
        {
            MCQQuestions = (MCQQuestion[]) _MCQQuestion.Clone();
            MCQAnswers = new int[_NumberofQuestions];
            TotalMarks = _TotalMarks;
        }


        #endregion

        #region Methods
        public override void ShowExam()
        {
            for(int i = 0; i < NumberOfQuestions; i++)
            {
                Console.WriteLine(MCQQuestions[i]);
                Console.WriteLine("---------------------------------------------------");
                int _Answer;
                do
                {
                    int.TryParse(Console.ReadLine(), out _Answer);
                    // 1, 2, 3
                } while (_Answer <= 0 || _Answer > 3);
                MCQAnswers[i] = _Answer - 1;
                if (MCQQuestions[i].RightAnswerIndex == MCQAnswers[i])
                {
                    Grade += MCQQuestions[i].Mark;
                }
            }
            /// Exam Had Been Finished
            Console.WriteLine(ToString());
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Right Answers: ");
            for(int i=0;i<NumberOfQuestions;i++)
            {
                sb.AppendLine($"Q{i+1},   {MCQQuestions[i].Answers[MCQQuestions[i].RightAnswerIndex].AnswerText}");
            }
            return sb.ToString();
        }

        #endregion
    }
}
